﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Degree_Application.Data
{
    public class CustomData
    {
        public enum StatusEnum
        {
            Used =1,
            New = 2
        }

        public enum SaleStatus
        {
            New = 1,
            Sold = 2
        }

    }
}
